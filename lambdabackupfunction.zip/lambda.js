'use strict';
// const AWS = require('aws-sdk');
var AWS = require('aws-sdk');
var fs = require('fs');
// AWS.config.update({region:'eu-west-1'});
var exec = require('child_process').exec;
var zipFolder = require('zip-folder');
var s3bucket = new AWS.S3({
    params: {
        Bucket: 'trainerzone-backups'
    }
});
module.exports.handler = function(event, context, cb) {
    process.env['PATH'] = process.env['PATH'] + ':' + process.env['LAMBDA_TASK_ROOT']
    console.log(process.env['PATH']);
    var fileName = (new Date()).toDateString().replace(/ /g, "") +"_"+ (new Date()).getTime();
    var folderName = '/tmp/' + fileName + "/"
    exec('mongodump -h ds055706-a0.mlab.com:55706 -d trainerzone -u trainerzone -p hinanit7 -o ' + folderName, (error, stdout, stderr) => {
        if (error) {
            console.error(`exec error: ${error}`);
            return;
        }
        console.log(`stdout: ${stdout}`);
        console.log(`stderr: ${stderr}`);
        var filePath = "/tmp/" + fileName + ".zip";

        zipFolder(folderName, filePath, function(err) {
            if (err) {
                console.log('oh no!', err);
            } else {
                console.log('EXCELLENT');
                fs.readFile(filePath, function(err, data) {
                    s3bucket.createBucket(function() {
                        var params = {
                            Key: fileName, //file.name doesn't exist as a property
                            Body: data
                        };
                        s3bucket.upload(params, function(err, data) {
                            // Whether there is an error or not, delete the temp file
                            fs.unlink(filePath, function(err) {
                                if (err) {
                                    console.error(err);
                                }
                                console.log('Temp File Delete');
                            });


                            if (err) {
                                console.log('ERROR MSG: ', err);

                            } else {
                                console.log('Successfully uploaded data');

                            }
                        });
                    });
                });
            }

        })
    });

};
